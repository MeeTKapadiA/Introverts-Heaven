import { Application } from '@nativescript/core';
import { installMixins } from '@nativescript/core/ui/core/view';

// Install mixins for proper navigation
installMixins();

// Register entry modules for navigation
global.registerModule("views/home/home-page", () => require("./views/home/home-page"));
global.registerModule("views/chatbot/chatbot-page", () => require("./views/chatbot/chatbot-page"));
global.registerModule("views/matching/matching-page", () => require("./views/matching/matching-page"));

Application.run({ moduleName: 'app-root' });