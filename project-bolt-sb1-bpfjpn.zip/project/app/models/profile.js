import { Observable } from '@nativescript/core';

export class Profile extends Observable {
    constructor() {
        super();
        this.name = '';
        this.age = null;
        this.bio = '';
        this.interests = [];
        this.photos = [];
        this.introvertScore = 0;
        this.preferences = {
            ageRange: { min: 18, max: 99 },
            distance: 50,
            communicationStyle: 'text',
            activityPreferences: []
        };
    }
}