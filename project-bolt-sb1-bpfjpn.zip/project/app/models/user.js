import { Observable } from '@nativescript/core';

export class User extends Observable {
    constructor() {
        super();
        this.name = '';
        this.bio = '';
        this.interests = [];
        this.introvertScore = 0;
    }
}