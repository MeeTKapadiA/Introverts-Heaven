export class ChatbotService {
    static getIntrovertQuestions() {
        return [
            {
                id: 1,
                question: "Do you prefer deep one-on-one conversations over large group gatherings?",
                options: ["Always", "Usually", "Sometimes", "Rarely"]
            },
            {
                id: 2,
                question: "How do you typically recharge after socializing?",
                options: ["Alone time", "Reading", "Quiet activities", "Light interaction"]
            },
            {
                id: 3,
                question: "What's your ideal first date?",
                options: ["Quiet café", "Museum visit", "Nature walk", "Book store browsing"]
            },
            {
                id: 4,
                question: "How do you prefer to communicate initially?",
                options: ["Text messages", "Voice messages", "Short video", "In-person meeting"]
            }
        ];
    }

    static generateResponse(answer) {
        const responses = {
            "Always": "That's a classic introvert trait! Your preference for meaningful conversations will help you form deeper connections.",
            "Usually": "You seem to value quality over quantity in your social interactions.",
            "Sometimes": "Balance is important! You know when to engage and when to step back.",
            "Rarely": "Everyone has their own comfort level with social interactions.",
            "Alone time": "Perfect! Taking time to recharge is essential for introverts.",
            "Reading": "Books can be the perfect companions for recharging!",
            "Quiet activities": "Finding peace in solitary activities is a wonderful trait.",
            "Light interaction": "Maintaining a gentle social connection while recharging shows good balance.",
            "Quiet café": "A peaceful setting perfect for meaningful conversation.",
            "Museum visit": "An excellent choice for sharing experiences without constant conversation.",
            "Nature walk": "Nature provides a perfect backdrop for authentic connection.",
            "Book store browsing": "Sharing literary interests can spark deep conversations.",
            "Text messages": "Written communication allows for thoughtful expression.",
            "Voice messages": "A nice balance between personal touch and comfort.",
            "Short video": "Visual connection while maintaining personal space.",
            "In-person meeting": "Face-to-face interaction can be meaningful when you're ready."
        };
        return responses[answer] || "Thank you for sharing your perspective.";
    }
}