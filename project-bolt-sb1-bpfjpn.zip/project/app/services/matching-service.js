export class MatchingService {
    static getDummyMatches() {
        return [
            {
                id: 1,
                name: "Sarah",
                age: 28,
                bio: "Bookworm and tea enthusiast. Looking for deep conversations about life and the universe.",
                interests: ["Reading", "Philosophy", "Art"],
                introvertScore: 85,
                photo: "https://raw.githubusercontent.com/NativeScript/sample-data/main/images/profile1.jpg",
                status: "pending"
            },
            {
                id: 2,
                name: "Alex",
                age: 31,
                bio: "Quiet photographer who enjoys nature walks and meaningful conversations.",
                interests: ["Photography", "Hiking", "Coffee"],
                introvertScore: 75,
                photo: "https://raw.githubusercontent.com/NativeScript/sample-data/main/images/profile2.jpg",
                status: null
            },
            {
                id: 3,
                name: "Emma",
                age: 26,
                bio: "Aspiring writer and cat lover. Seeking someone to share cozy reading sessions.",
                interests: ["Writing", "Cats", "Tea", "Books"],
                introvertScore: 90,
                photo: "https://raw.githubusercontent.com/NativeScript/sample-data/main/images/profile3.jpg",
                status: null
            },
            {
                id: 4,
                name: "James",
                age: 30,
                bio: "Software developer by day, stargazer by night. Let's discuss the cosmos.",
                interests: ["Technology", "Astronomy", "Science"],
                introvertScore: 80,
                photo: "https://raw.githubusercontent.com/NativeScript/sample-data/main/images/profile4.jpg",
                status: "accepted"
            },
            {
                id: 5,
                name: "Luna",
                age: 27,
                bio: "Art gallery curator with a passion for indie films and quiet cafes.",
                interests: ["Art", "Films", "Coffee"],
                introvertScore: 70,
                photo: "https://raw.githubusercontent.com/NativeScript/sample-data/main/images/profile5.jpg",
                status: null
            },
            {
                id: 6,
                name: "Oliver",
                age: 29,
                bio: "Botanical garden enthusiast and amateur herbalist. Seeking peaceful connections.",
                interests: ["Nature", "Gardening", "Meditation"],
                introvertScore: 85,
                photo: "https://raw.githubusercontent.com/NativeScript/sample-data/main/images/profile6.jpg",
                status: null
            },
            {
                id: 7,
                name: "Mia",
                age: 25,
                bio: "Classical musician and bookstore wanderer. Looking for deep, meaningful conversations.",
                interests: ["Music", "Literature", "Art"],
                introvertScore: 88,
                photo: "https://raw.githubusercontent.com/NativeScript/sample-data/main/images/profile7.jpg",
                status: null
            },
            {
                id: 8,
                name: "Liam",
                age: 32,
                bio: "Chess player and philosophy enthusiast. Let's discuss life's big questions.",
                interests: ["Chess", "Philosophy", "Reading"],
                introvertScore: 82,
                photo: "https://raw.githubusercontent.com/NativeScript/sample-data/main/images/profile8.jpg",
                status: "accepted"
            },
            {
                id: 9,
                name: "Sophie",
                age: 28,
                bio: "Marine biologist with a love for underwater photography and quiet beaches.",
                interests: ["Photography", "Nature", "Science"],
                introvertScore: 75,
                photo: "https://raw.githubusercontent.com/NativeScript/sample-data/main/images/profile9.jpg",
                status: null
            },
            {
                id: 10,
                name: "Nathan",
                age: 30,
                bio: "Minimalist artist seeking genuine connections through shared creativity.",
                interests: ["Art", "Minimalism", "Meditation"],
                introvertScore: 87,
                photo: "https://raw.githubusercontent.com/NativeScript/sample-data/main/images/profile10.jpg",
                status: null
            }
        ];
    }

    static getMessages() {
        return [
            {
                id: 1,
                from: "James",
                message: "Hey! Would you like to visit the observatory this weekend?",
                time: "2 hours ago",
                unread: true,
                photo: "https://raw.githubusercontent.com/NativeScript/sample-data/main/images/profile4.jpg"
            },
            {
                id: 2,
                from: "Liam",
                message: "I found this interesting book on philosophy you might enjoy.",
                time: "1 day ago",
                unread: false,
                photo: "https://raw.githubusercontent.com/NativeScript/sample-data/main/images/profile8.jpg"
            }
        ];
    }

    static getInterests() {
        return [
            "Reading", "Writing", "Art", "Music",
            "Photography", "Nature", "Hiking", "Coffee",
            "Tea", "Movies", "Philosophy", "Science",
            "Technology", "Cooking", "Gaming", "Meditation"
        ];
    }

    static getActivityPreferences() {
        return [
            "Quiet café visits",
            "Museum tours",
            "Nature walks",
            "Book store browsing",
            "Art gallery visits",
            "Library meetups",
            "Small group discussions",
            "One-on-one conversations"
        ];
    }
}