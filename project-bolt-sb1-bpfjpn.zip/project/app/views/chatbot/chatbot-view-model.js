import { Observable, Frame } from '@nativescript/core';
import { ChatbotService } from '../../services/chatbot-service';

export function createViewModel() {
    const viewModel = new Observable();
    const questions = ChatbotService.getIntrovertQuestions();
    let currentQuestionIndex = 0;

    // Initialize the first question
    viewModel.set('currentQuestion', questions[currentQuestionIndex].question);
    viewModel.set('options', questions[currentQuestionIndex].options);
    viewModel.set('botResponse', '');
    viewModel.set('progress', `Question ${currentQuestionIndex + 1}/${questions.length}`);

    viewModel.onAnswerTap = (args) => {
        const button = args.object;
        const page = button.page;
        const selectedAnswer = button.text;
        
        const response = ChatbotService.generateResponse(selectedAnswer);
        viewModel.set('botResponse', response);

        // Move to next question after a shorter delay
        setTimeout(() => {
            currentQuestionIndex++;
            if (currentQuestionIndex < questions.length) {
                viewModel.set('currentQuestion', questions[currentQuestionIndex].question);
                viewModel.set('options', questions[currentQuestionIndex].options);
                viewModel.set('botResponse', '');
                viewModel.set('progress', `Question ${currentQuestionIndex + 1}/${questions.length}`);
            } else {
                // Navigate to matching page when questions are finished
                page.frame.navigate({
                    moduleName: "views/matching/matching-page",
                    animated: true,
                    transition: {
                        name: "slide",
                        duration: 300
                    },
                    clearHistory: true // Clear navigation history
                });
            }
        }, 1000); // Reduced delay to 1 second
    };

    return viewModel;
}