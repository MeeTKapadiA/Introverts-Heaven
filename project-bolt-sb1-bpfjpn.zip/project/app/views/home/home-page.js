import { Frame, NavigatedData, Page } from '@nativescript/core';

export function onNavigatingTo(args) {
    const page = args.object;
}

export function onStartJourney(args) {
    const page = args.object.page;
    page.frame.navigate({
        moduleName: "views/chatbot/chatbot-page",
        animated: true,
        transition: {
            name: "slide",
            duration: 300
        }
    });
}