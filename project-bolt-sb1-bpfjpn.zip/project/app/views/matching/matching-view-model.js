import { Observable } from '@nativescript/core';
import { MatchingService } from '../../services/matching-service';
import { Profile } from '../../models/profile';

export function createViewModel() {
    const viewModel = new Observable();
    
    // Initialize properties
    viewModel.profile = new Profile();
    viewModel.matches = MatchingService.getDummyMatches();
    viewModel.messages = MatchingService.getMessages();
    viewModel.interests = MatchingService.getInterests();
    viewModel.activityPreferences = MatchingService.getActivityPreferences();
    viewModel.currentView = 'matches';
    viewModel.showingInbox = false;
    viewModel.unreadCount = viewModel.messages.filter(m => m.unread).length;
    
    viewModel.toggleView = (args) => {
        const view = args.object.param;
        viewModel.set('currentView', view);
    };

    viewModel.showInbox = () => {
        viewModel.set('showingInbox', true);
        // Mark messages as read
        viewModel.messages.forEach(m => m.unread = false);
        viewModel.set('unreadCount', 0);
    };

    viewModel.closeInbox = () => {
        viewModel.set('showingInbox', false);
    };

    viewModel.onFriendRequest = (args) => {
        const matchId = parseInt(args.object.parent.matchId);
        const match = viewModel.matches.find(m => m.id === matchId);
        
        if (!match.status) {
            match.status = 'pending';
            viewModel.matches = [...viewModel.matches]; // Trigger update
            alert({
                title: "Friend Request Sent",
                message: `Your friend request has been sent to ${match.name}!`,
                okButtonText: "OK"
            });
        } else if (match.status === 'accepted') {
            // Open chat
            alert({
                title: "Open Chat",
                message: `Start chatting with ${match.name}?`,
                okButtonText: "Yes",
                cancelButtonText: "Later"
            });
        }
    };

    viewModel.onMatchTap = (args) => {
        const matchId = parseInt(args.object.matchId);
        const match = viewModel.matches.find(m => m.id === matchId);
        
        alert({
            title: match.name,
            message: `Introvert Score: ${match.introvertScore}%\n\nInterests: ${match.interests.join(', ')}\n\n${match.bio}`,
            okButtonText: "Close"
        });
    };

    // Existing methods remain the same
    viewModel.updateProfile = () => {
        alert({
            title: "Success",
            message: "Profile updated successfully!",
            okButtonText: "OK"
        });
    };

    viewModel.onInterestSelect = (args) => {
        const interest = args.object.text;
        const currentInterests = viewModel.profile.interests;
        
        if (currentInterests.includes(interest)) {
            viewModel.profile.interests = currentInterests.filter(i => i !== interest);
        } else {
            viewModel.profile.interests = [...currentInterests, interest];
        }
        
        viewModel.notifyPropertyChange('profile', viewModel.profile);
    };

    return viewModel;
}