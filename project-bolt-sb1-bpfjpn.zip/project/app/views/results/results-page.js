import { Frame } from '@nativescript/core';

export function onNavigatingTo(args) {
    const page = args.object;
}

export function onStartMatching(args) {
    alert({
        title: "Coming Soon",
        message: "The matching feature will be available in the next update!",
        okButtonText: "OK"
    });
}

export function onReturnHome(args) {
    const page = args.object.page;
    page.frame.navigate({
        moduleName: "views/home/home-page",
        animated: true,
        transition: {
            name: "slideRight",
            duration: 300
        },
        clearHistory: true
    });
}